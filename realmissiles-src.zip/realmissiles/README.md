# Real Missiles (Forge 1.20.1 + GeckoLib 4)

## Сборка jar без ПК (GitHub Actions)
1. Создайте репозиторий на github.com (через браузер планшета).
2. Загрузите в корень репозитория файл realmissiles-src.zip (Add file -> Upload files).
3. Создайте файл .github/workflows/build.yml (Add file -> Create new file, в имени введите путь со слэшами) и вставьте workflow из чата.
4. Вкладка Actions -> build -> когда закончится (5-15 мин) скачайте artifact realmissiles-jar. Внутри будет realmissiles-0.1.0.jar.

## Установка в игру
Положите jar в mods вместе с GeckoLib 4.x для Forge 1.20.1 и Explosion Overhaul.
Тест (нужен OP): /missile launch iskander ~ ~ ~500
Конфиг: config/realmissiles-common.toml

## Что внутри
- MissileType: баланс одной таблицей
- MissileEntity: полёт, хитбокс, урон, перехват, РЭБ-хук jam()
- ExplosionHelper: взрывы через Level.explode (подхватывает Explosion Overhaul)
- assets/.../geo: временные модели, замените своими из Blockbench

## Не проверено
Код не компилировался в среде создания, возможны мелкие правки.
modid Explosion Overhaul подставлен предположительно, поменяйте в конфиге.
