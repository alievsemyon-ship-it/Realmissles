package ru.realmissiles.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import ru.realmissiles.config.MissileConfig;
import ru.realmissiles.missile.MissileType;
import ru.realmissiles.registry.ModEntities;
import ru.realmissiles.util.ExplosionHelper;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public class MissileEntity extends Entity implements GeoEntity {
    public enum Phase { BOOST, CRUISE, TERMINAL }

    private static final RawAnimation FLY = RawAnimation.begin().thenLoop("animation.missile.fly");

    private final MissileType type;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private Vec3 launchPos = Vec3.ZERO;
    private Vec3 target = Vec3.ZERO;
    private Vec3 apex = Vec3.ZERO;
    private Phase phase = Phase.BOOST;
    private float health;
    private int ticks;
    private boolean armed;

    public MissileEntity(EntityType<?> entityType, Level level, MissileType type) {
        super(entityType, level);
        this.type = type;
        this.health = type.health;
        this.noCulling = true;
        this.setNoGravity(true);
    }

    public MissileType getMissileType() { return type; }
    public Phase getPhase() { return phase; }
    public Vec3 getTarget() { return target; }
    public float getHealth() { return health; }

    // ---------- запуск ----------
    public void launch(Vec3 target) {
        this.target = target;
        this.launchPos = position();
        this.armed = true;
        Vec3 mid = launchPos.add(target).scale(0.5);
        this.apex = new Vec3(mid.x, Math.max(launchPos.y, target.y) + type.apexHeight, mid.z);
    }

    public void launchTerminal(Vec3 target) {
        launch(target);
        this.phase = Phase.TERMINAL;
    }

    /** Вызывается РЭБ: сбивает наведение пропорционально уязвимости ракеты. */
    public void jam(double strength) {
        double chance = Mth.clamp(strength * type.jamSusceptibility, 0, 1);
        if (chance > 0 && random.nextDouble() < chance) {
            target = target.add((random.nextDouble() - 0.5) * 80 * chance, 0,
                    (random.nextDouble() - 0.5) * 80 * chance);
        }
    }

    // ---------- тик ----------
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) { clientTrail(); return; }
        if (!armed) { discard(); return; }

        ticks++;
        if (ticks > 20 * 60 * 5) { detonate(); return; }

        Vec3 dir = steer();
        if (isRemoved()) return;

        double speed = speed();
        Vec3 vel = dir.scale(speed);
        setDeltaMovement(vel);
        move(MoverType.SELF, vel);
        orient(vel);

        if (horizontalCollision || verticalCollision || position().distanceToSqr(target) <= speed * speed) {
            detonate();
        }
    }

    private double speed() {
        double s = type.speed * MissileConfig.SPEED_SCALE.get();
        if (phase == Phase.BOOST) s = Math.min(s, 0.4 + ticks * 0.06);
        else if (phase == Phase.TERMINAL) s *= type.terminalMul;
        return s;
    }

    private Vec3 toTarget() { return target.subtract(position()).normalize(); }

    private double launchHd() {
        return Math.sqrt((target.x - launchPos.x) * (target.x - launchPos.x)
                + (target.z - launchPos.z) * (target.z - launchPos.z));
    }

    private Vec3 steer() {
        Vec3 pos = position();
        double fx = target.x - pos.x, fz = target.z - pos.z;
        double hd = Math.sqrt(fx * fx + fz * fz);
        double dx = hd > 1e-4 ? fx / hd : 0, dz = hd > 1e-4 ? fz / hd : 0;

        if (phase == Phase.BOOST) {
            if (ticks >= type.boostTicks) phase = Phase.CRUISE;
            return new Vec3(dx * 0.3, 1, dz * 0.3).normalize();
        }
        if (phase == Phase.CRUISE) {
            if (type.isCruise()) {
                if (hd < type.terminalDist) { phase = Phase.TERMINAL; return toTarget(); }
                int ground = level().getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(pos.x), Mth.floor(pos.z));
                double wantY = ground + type.cruiseAlt;
                double dy = Mth.clamp((wantY - pos.y) * 0.08, -0.35, 0.35);
                return new Vec3(dx, dy, dz).normalize();
            }
            Vec3 toApex = apex.subtract(pos);
            if (toApex.length() < 40 || hd < launchHd() * 0.45) { phase = Phase.TERMINAL; return toTarget(); }
            return toApex.normalize();
        }
        // TERMINAL
        if (type.splitCount > 0 && pos.distanceTo(target) <= type.splitDistance) {
            split();
            return Vec3.ZERO;
        }
        return toTarget();
    }

    private void orient(Vec3 v) {
        float yaw = (float) (Mth.atan2(v.x, v.z) * Mth.RAD_TO_DEG);
        float pitch = (float) (-(Mth.atan2(v.y, v.horizontalDistance()) * Mth.RAD_TO_DEG));
        setYRot(yaw);
        setXRot(pitch);
    }

    // ---------- боеголовки / взрыв ----------
    private void split() {
        if (!(level() instanceof ServerLevel sl)) return;
        Vec3 p = position();
        MissileType wt = MissileType.WARHEAD;
        for (int i = 0; i < type.splitCount; i++) {
            double a = i * (Math.PI * 2 / type.splitCount) + random.nextDouble() * 0.5;
            double r = 12 + random.nextDouble() * 22;
            Vec3 aim = target.add(Math.cos(a) * r, 0, Math.sin(a) * r);
            MissileEntity w = new MissileEntity(ModEntities.of(wt), sl, wt);
            w.setPos(p);
            w.launchTerminal(aim);
            sl.addFreshEntity(w);
        }
        discard();
    }

    private void detonate() {
        if (!(level() instanceof ServerLevel sl) || isRemoved()) return;
        Vec3 p = position();
        discard();
        ExplosionHelper.detonate(sl, p, type);
    }

    private void shootDown() {
        if (!(level() instanceof ServerLevel sl) || isRemoved()) return;
        Vec3 p = position();
        discard();
        float power = Math.max(2f, type.power * 0.25f * MissileConfig.POWER_SCALE.get().floatValue());
        sl.explode(null, p.x, p.y, p.z, power, false, Level.ExplosionInteraction.NONE);
    }

    // ---------- хитбокс и урон ----------
    /** true => пули, стрелы и удары попадают в ракету, а не пролетают насквозь. */
    @Override public boolean isPickable() { return true; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved() || isInvulnerableTo(source)) return false;
        float dmg = source.is(DamageTypeTags.IS_EXPLOSION)
                ? amount * (1f - type.explosionResist)
                : amount * (1f - type.armor);
        health -= dmg;
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.CRIT, getX(), getY() + type.height / 2, getZ(), 3, 0.2, 0.2, 0.2, 0.1);
        }
        if (health <= 0) shootDown();
        return true;
    }

    // ---------- клиент: лёгкий дымовой след ----------
    private void clientTrail() {
        if (tickCount % 2 != 0) return;
        float yaw = getYRot() * Mth.DEG_TO_RAD, pitch = getXRot() * Mth.DEG_TO_RAD;
        double lx = Mth.sin(yaw) * Mth.cos(pitch), ly = -Mth.sin(pitch), lz = Mth.cos(yaw) * Mth.cos(pitch);
        double bx = getX() - lx * 2.0, by = getY() + type.height / 2 - ly * 2.0, bz = getZ() - lz * 2.0;
        level().addParticle(ParticleTypes.LARGE_SMOKE, bx, by, bz, 0, 0, 0);
        if (tickCount % 4 == 0) level().addParticle(ParticleTypes.FLAME, bx, by, bz, 0, 0, 0);
    }

    // ---------- сохранение ----------
    @Override protected void defineSynchedData() {}

    @Override
    protected void readAdditionalSaveData(CompoundTag t) {
        armed = t.getBoolean("Armed");
        ticks = t.getInt("Ticks");
        health = t.contains("Health") ? t.getFloat("Health") : type.health;
        phase = Phase.values()[Mth.clamp(t.getInt("Phase"), 0, 2)];
        target = new Vec3(t.getDouble("Tx"), t.getDouble("Ty"), t.getDouble("Tz"));
        apex = new Vec3(t.getDouble("Ax"), t.getDouble("Ay"), t.getDouble("Az"));
        launchPos = new Vec3(t.getDouble("Lx"), t.getDouble("Ly"), t.getDouble("Lz"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag t) {
        t.putBoolean("Armed", armed);
        t.putInt("Ticks", ticks);
        t.putFloat("Health", health);
        t.putInt("Phase", phase.ordinal());
        t.putDouble("Tx", target.x); t.putDouble("Ty", target.y); t.putDouble("Tz", target.z);
        t.putDouble("Ax", apex.x); t.putDouble("Ay", apex.y); t.putDouble("Az", apex.z);
        t.putDouble("Lx", launchPos.x); t.putDouble("Ly", launchPos.y); t.putDouble("Lz", launchPos.z);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    // ---------- GeckoLib ----------
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 0, state -> state.setAndContinue(FLY)));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
