package ru.realmissiles.client;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import ru.realmissiles.RealMissilesMod;
import ru.realmissiles.entity.MissileEntity;
import ru.realmissiles.missile.MissileType;
import ru.realmissiles.registry.ModEntities;

@Mod.EventBusSubscriber(modid = RealMissilesMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers e) {
        for (MissileType t : MissileType.values()) {
            e.registerEntityRenderer(ModEntities.of(t), ctx -> new MissileRenderer(ctx, t.id));
        }
    }

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(() -> MissileEntity.CLIENT_TICK = MissileFx::tick);
    }

    private ClientSetup() {}
}
