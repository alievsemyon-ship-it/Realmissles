package ru.realmissiles.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import ru.realmissiles.config.MissileConfig;
import ru.realmissiles.missile.MissileType;
import ru.realmissiles.network.LaunchPacket;
import ru.realmissiles.network.ModNetwork;

/** Меню запуска: режим «координаты» или «по взгляду». */
public class LaunchScreen extends Screen {
    private final MissileType type;
    private final InteractionHand hand;
    private int mode = 0;
    private EditBox xBox, yBox, zBox;
    private Button modeBtn, launchBtn;
    private Vec3 lookTarget;

    public LaunchScreen(MissileType type, InteractionHand hand) {
        super(Component.translatable("entity.realmissiles." + type.id));
        this.type = type;
        this.hand = hand;
    }

    @Override
    protected void init() {
        LocalPlayer pl = Minecraft.getInstance().player;
        lookTarget = null;
        if (pl != null) {
            HitResult h = pl.pick(MissileConfig.LOOK_RANGE.get(), 1.0f, false);
            if (h.getType() != HitResult.Type.MISS) lookTarget = h.getLocation();
        }
        int cx = width / 2, top = height / 2 - 75;

        modeBtn = addRenderableWidget(Button.builder(modeText(), b -> {
            mode = 1 - mode;
            b.setMessage(modeText());
            refresh();
        }).bounds(cx - 100, top + 18, 200, 20).build());

        double px = lookTarget != null ? lookTarget.x : (pl != null ? pl.getX() : 0);
        double py = lookTarget != null ? lookTarget.y : (pl != null ? pl.getY() : 64);
        double pz = lookTarget != null ? lookTarget.z : (pl != null ? pl.getZ() : 0);
        xBox = box(cx - 100, top + 55, (int) Math.floor(px), "X");
        yBox = box(cx - 33, top + 55, (int) Math.floor(py), "Y");
        zBox = box(cx + 34, top + 55, (int) Math.floor(pz), "Z");

        launchBtn = addRenderableWidget(Button.builder(Component.translatable("gui.realmissiles.launch"),
                b -> doLaunch()).bounds(cx - 100, top + 100, 200, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("gui.realmissiles.cancel"),
                b -> onClose()).bounds(cx - 100, top + 125, 200, 20).build());
        refresh();
    }

    private EditBox box(int x, int y, int value, String label) {
        EditBox e = new EditBox(font, x, y, 66, 20, Component.literal(label));
        e.setFilter(s -> s.matches("-?\\d*"));
        e.setMaxLength(8);
        e.setValue(String.valueOf(value));
        addRenderableWidget(e);
        return e;
    }

    private Component modeText() {
        return Component.translatable(mode == 0 ? "gui.realmissiles.mode.coords" : "gui.realmissiles.mode.look");
    }

    private void refresh() {
        boolean coords = mode == 0;
        xBox.visible = coords;
        yBox.visible = coords;
        zBox.visible = coords;
    }

    /** Цель в текущем режиме или null, если она неверна. */
    private Vec3 currentTarget() {
        if (mode == 1) return lookTarget;
        try {
            return new Vec3(Integer.parseInt(xBox.getValue()) + 0.5, Integer.parseInt(yBox.getValue()),
                    Integer.parseInt(zBox.getValue()) + 0.5);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void doLaunch() {
        Vec3 t = currentTarget();
        if (t == null) return;
        ModNetwork.CHANNEL.sendToServer(new LaunchPacket(hand == InteractionHand.MAIN_HAND, mode, t.x, t.y, t.z));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int cx = width / 2, top = height / 2 - 75;
        g.drawCenteredString(font, title, cx, top, 0xFFFFFF);
        if (mode == 0) {
            g.drawString(font, "X", cx - 100, top + 44, 0xAAAAAA);
            g.drawString(font, "Y", cx - 33, top + 44, 0xAAAAAA);
            g.drawString(font, "Z", cx + 34, top + 44, 0xAAAAAA);
        }

        Vec3 t = currentTarget();
        LocalPlayer pl = Minecraft.getInstance().player;
        Component info;
        if (t == null) {
            info = Component.translatable(mode == 1 ? "gui.realmissiles.info.nolook" : "gui.realmissiles.info.badnum");
        } else if (pl != null) {
            double d = t.distanceTo(pl.position());
            int eta = (int) (d / (type.speed * MissileConfig.SPEED_SCALE.get() * 20.0) * (type.isCruise() ? 1.0 : 0.85));
            info = Component.translatable("gui.realmissiles.info.dist", (int) d, eta);
            if (mode == 1) {
                g.drawCenteredString(font, Component.translatable("gui.realmissiles.info.look",
                        (int) t.x, (int) t.y, (int) t.z), cx, top + 55, 0xDDDDDD);
            }
        } else {
            info = Component.empty();
        }
        g.drawCenteredString(font, info, cx, top + 82, 0xAAAAAA);
        launchBtn.active = t != null;
        super.render(g, mx, my, pt);
    }

    @Override public boolean isPauseScreen() { return false; }
}
