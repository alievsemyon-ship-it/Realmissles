package ru.realmissiles.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.util.Mth;
import ru.realmissiles.entity.MissileEntity;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

public class MissileRenderer extends GeoEntityRenderer<MissileEntity> {
    public MissileRenderer(EntityRendererProvider.Context ctx, String name) {
        super(ctx, new MissileModel(name));
        this.shadowRadius = 0f;
        // Пламя светится в темноте (текстура *_glowmask.png)
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    /** Нос модели смотрит в -Z. Поворачиваем вокруг центра хитбокса по вектору полёта. */
    @Override
    protected void applyRotations(MissileEntity e, PoseStack ps, float age, float yaw, float pt) {
        float y = Mth.rotLerp(pt, e.yRotO, e.getYRot());
        float x = Mth.lerp(pt, e.xRotO, e.getXRot());
        float c = e.getBbHeight() / 2f;
        ps.translate(0, c, 0);
        ps.mulPose(Axis.YP.rotationDegrees(180f - y));
        ps.mulPose(Axis.XP.rotationDegrees(-x));
        ps.translate(0, -c, 0);
    }
}
