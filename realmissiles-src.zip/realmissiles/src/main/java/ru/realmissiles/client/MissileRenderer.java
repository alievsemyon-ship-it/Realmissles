package ru.realmissiles.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.util.Mth;
import ru.realmissiles.entity.MissileEntity;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class MissileRenderer extends GeoEntityRenderer<MissileEntity> {
    public MissileRenderer(EntityRendererProvider.Context ctx, String name) {
        super(ctx, new MissileModel(name));
        this.shadowRadius = 0f;
    }

    /** Не-living сущности GeckoLib сам не вращает: ориентируем нос по вектору полёта. */
    @Override
    protected void applyRotations(MissileEntity e, PoseStack ps, float age, float yaw, float pt) {
        float y = Mth.rotLerp(pt, e.yRotO, e.getYRot());
        float x = Mth.lerp(pt, e.xRotO, e.getXRot());
        ps.mulPose(Axis.YP.rotationDegrees(180f - y));
        ps.mulPose(Axis.XP.rotationDegrees(-x));
    }
}
