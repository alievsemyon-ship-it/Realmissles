package ru.realmissiles.client;

import net.minecraft.resources.ResourceLocation;
import ru.realmissiles.RealMissilesMod;
import ru.realmissiles.entity.MissileEntity;
import software.bernie.geckolib.model.GeoModel;

public class MissileModel extends GeoModel<MissileEntity> {
    private final ResourceLocation model, texture, animation;

    public MissileModel(String name) {
        model = new ResourceLocation(RealMissilesMod.MODID, "geo/entity/" + name + ".geo.json");
        texture = new ResourceLocation(RealMissilesMod.MODID, "textures/entity/" + name + ".png");
        animation = new ResourceLocation(RealMissilesMod.MODID, "animations/entity/" + name + ".animation.json");
    }

    @Override public ResourceLocation getModelResource(MissileEntity e) { return model; }
    @Override public ResourceLocation getTextureResource(MissileEntity e) { return texture; }
    @Override public ResourceLocation getAnimationResource(MissileEntity e) { return animation; }
}
