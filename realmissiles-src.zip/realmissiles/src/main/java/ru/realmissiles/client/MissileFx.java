package ru.realmissiles.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import ru.realmissiles.entity.MissileEntity;
import ru.realmissiles.missile.MissileType;

/** Эффекты полёта. Всё считается на клиенте, по сети частицы не передаются. */
public final class MissileFx {

    public static void tick(MissileEntity e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.isPaused()) return;

        Level lvl = e.level();
        RandomSource r = lvl.random;
        MissileType t = e.getMissileType();

        // Настройка частиц в игре: все / уменьшенные / минимальные
        double density = switch (mc.options.particles().get()) {
            case ALL -> 1.0;
            case DECREASED -> 0.5;
            case MINIMAL -> 0.2;
        };

        double h2 = e.getBbHeight() / 2.0;
        Vec3 cur = new Vec3(e.getX(), e.getY() + h2, e.getZ());
        Vec3 prev = new Vec3(e.xo, e.yo + h2, e.zo);
        double dist = mc.gameRenderer.getMainCamera().getPosition().distanceTo(cur);
        if (dist > 350) return;            // слишком далеко: не тратим ресурсы
        if (dist > 140) density *= 0.5;    // LOD: вдали вдвое меньше частиц

        Vec3 look = e.getLookAngle();
        Vec3 back = look.scale(-1);
        boolean engine = e.isEngineOn();
        boolean boost = e.getSyncedPhase() == 0;
        boolean warhead = t == MissileType.WARHEAD;

        // профиль: облако, густой дым, долгий дым, огонь, искры (на шаг следа)
        double[] p;
        switch (t) {
            case FLAMINGO -> p = new double[]{0.6, 0.25, 0.06, 0.3, 0.2};
            case ISKANDER -> p = new double[]{1.2, 0.8, 0.15, 0.6, 0.5};
            case ORESHNIK -> p = new double[]{1.7, 1.5, 0.25, 1.0, 1.0};
            default -> p = new double[]{0, 0, 0, 0, 0};
        }
        double k = (boost || t.isCruise()) ? 1.0 : 0.5;   // на маршевой тяга слабее

        // Точки следа вдоль пройденного пути, чтобы не было разрывов на высокой скорости
        int steps = Mth.clamp((int) Math.ceil(prev.distanceTo(cur) / 1.6), 1, 6);
        for (int i = 1; i <= steps; i++) {
            Vec3 c = prev.lerp(cur, (double) i / steps);
            Vec3 nozzle = c.add(back.scale(t.tailOffset()));

            if (engine) {
                emit(lvl, r, ParticleTypes.CLOUD, nozzle, 0.5, back.scale(0.04), p[0] * k * density);
                emit(lvl, r, ParticleTypes.LARGE_SMOKE, nozzle, 0.4, back.scale(0.05), p[1] * k * density);
                emit(lvl, r, ParticleTypes.CAMPFIRE_COSY_SMOKE, nozzle, 0.3, new Vec3(0, 0.01, 0), p[2] * k * density);
                if (boost) {
                    emit(lvl, r, ParticleTypes.FLAME, nozzle, 0.3, back.scale(0.12), p[3] * density);
                    emit(lvl, r, ParticleTypes.LAVA, nozzle, 0.3, Vec3.ZERO, p[4] * density);
                }
            } else if (warhead) {
                // раскалённая боеголовка: огненный след и дым
                emit(lvl, r, ParticleTypes.FLAME, c, 0.25, back.scale(0.05), 1.0 * density);
                emit(lvl, r, ParticleTypes.LARGE_SMOKE, c, 0.3, back.scale(0.04), 0.7 * density);
                emit(lvl, r, ParticleTypes.LAVA, c, 0.3, Vec3.ZERO, 0.4 * density);
            }
        }

        // Облако и вспышка у пусковой точки в первые секунды
        if (!warhead && boost && e.fxStart != null && e.tickCount <= 50) {
            Vec3 s = e.fxStart;
            int n = count(r, (e.tickCount < 25 ? 3.0 : 1.5) * density);
            for (int i = 0; i < n; i++) {
                double a = r.nextDouble() * Math.PI * 2, d = r.nextDouble() * 3;
                lvl.addAlwaysVisibleParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                        s.x + Math.cos(a) * d, s.y + 0.2, s.z + Math.sin(a) * d,
                        Math.cos(a) * 0.04, 0.03, Math.sin(a) * 0.04);
            }
            if (e.tickCount < 30) {
                int m = count(r, 2.0 * density);
                for (int i = 0; i < m; i++) {
                    double a = r.nextDouble() * Math.PI * 2;
                    lvl.addAlwaysVisibleParticle(ParticleTypes.LARGE_SMOKE,
                            s.x, s.y + 0.3, s.z, Math.cos(a) * 0.22, 0.02, Math.sin(a) * 0.22);
                }
            }
            if (e.tickCount < 12) {
                int f = count(r, 3.0 * density);
                for (int i = 0; i < f; i++) {
                    double a = r.nextDouble() * Math.PI * 2;
                    lvl.addAlwaysVisibleParticle(ParticleTypes.FLAME,
                            s.x, s.y + 0.2, s.z, Math.cos(a) * 0.18, 0.03, Math.sin(a) * 0.18);
                }
            }
        }
    }

    private static void emit(Level l, RandomSource r, ParticleOptions type, Vec3 pos, double spread, Vec3 vel, double amount) {
        int n = count(r, amount);
        for (int i = 0; i < n; i++) {
            l.addAlwaysVisibleParticle(type,
                    pos.x + (r.nextDouble() - 0.5) * spread,
                    pos.y + (r.nextDouble() - 0.5) * spread,
                    pos.z + (r.nextDouble() - 0.5) * spread,
                    vel.x + (r.nextDouble() - 0.5) * 0.02,
                    vel.y + (r.nextDouble() - 0.5) * 0.02,
                    vel.z + (r.nextDouble() - 0.5) * 0.02);
        }
    }

    private static int count(RandomSource r, double x) {
        int n = (int) x;
        if (r.nextDouble() < x - n) n++;
        return n;
    }

    private MissileFx() {}
}
