package ru.realmissiles;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import ru.realmissiles.config.ClientConfig;
import ru.realmissiles.config.MissileConfig;
import ru.realmissiles.registry.ModEntities;

@Mod(RealMissilesMod.MODID)
public class RealMissilesMod {
    public static final String MODID = "realmissiles";

    public RealMissilesMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, MissileConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }
}
