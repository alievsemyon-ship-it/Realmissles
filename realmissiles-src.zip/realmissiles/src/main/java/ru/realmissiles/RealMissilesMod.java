package ru.realmissiles;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import ru.realmissiles.config.ClientConfig;
import ru.realmissiles.config.MissileConfig;
import ru.realmissiles.network.ModNetwork;
import ru.realmissiles.registry.ModEntities;
import ru.realmissiles.registry.ModItems;
import ru.realmissiles.registry.ModTabs;

@Mod(RealMissilesMod.MODID)
public class RealMissilesMod {
    public static final String MODID = "realmissiles";

    public RealMissilesMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, MissileConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(ModNetwork::init);
    }
}
