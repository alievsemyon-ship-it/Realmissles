package ru.realmissiles.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import ru.realmissiles.entity.MissileEntity;

import java.util.function.Supplier;

/** Пилот нажал «подрыв» (для Орешника это разделение боеголовок). */
public class DetonatePacket {
    public static void encode(DetonatePacket m, FriendlyByteBuf b) {}
    public static DetonatePacket decode(FriendlyByteBuf b) { return new DetonatePacket(); }

    public static void handle(DetonatePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p != null && p.getVehicle() instanceof MissileEntity me && me.isPilot(p)) {
                me.manualDetonate();
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
