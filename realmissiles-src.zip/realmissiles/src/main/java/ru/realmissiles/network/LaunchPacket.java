package ru.realmissiles.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import ru.realmissiles.server.LaunchHandler;

import java.util.function.Supplier;

/** mode: 0 = координаты, 1 = по взгляду. Тип ракеты сервер берёт из предмета в руке. */
public class LaunchPacket {
    public final boolean mainHand;
    public final int mode;
    public final double x, y, z;

    public LaunchPacket(boolean mainHand, int mode, double x, double y, double z) {
        this.mainHand = mainHand; this.mode = mode; this.x = x; this.y = y; this.z = z;
    }

    public static void encode(LaunchPacket m, FriendlyByteBuf b) {
        b.writeBoolean(m.mainHand);
        b.writeVarInt(m.mode);
        b.writeDouble(m.x); b.writeDouble(m.y); b.writeDouble(m.z);
    }

    public static LaunchPacket decode(FriendlyByteBuf b) {
        return new LaunchPacket(b.readBoolean(), b.readVarInt(), b.readDouble(), b.readDouble(), b.readDouble());
    }

    public static void handle(LaunchPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p != null) LaunchHandler.handle(p, m);
        });
        ctx.get().setPacketHandled(true);
    }
}
