package ru.realmissiles.network;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import ru.realmissiles.RealMissilesMod;

public final class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(RealMissilesMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void init() {
        int id = 0;
        CHANNEL.registerMessage(id++, LaunchPacket.class, LaunchPacket::encode, LaunchPacket::decode, LaunchPacket::handle);
        CHANNEL.registerMessage(id++, DetonatePacket.class, DetonatePacket::encode, DetonatePacket::decode, DetonatePacket::handle);
    }

    private ModNetwork() {}
}
