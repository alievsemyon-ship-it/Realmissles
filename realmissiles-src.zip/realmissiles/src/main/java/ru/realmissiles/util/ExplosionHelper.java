package ru.realmissiles.util;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.fml.ModList;
import ru.realmissiles.config.MissileConfig;
import ru.realmissiles.missile.MissileType;

public final class ExplosionHelper {

    public static boolean overhaulPresent() {
        return ModList.get().isLoaded(MissileConfig.EXPLOSION_MOD_ID.get());
    }

    /**
     * Взрывы идут через ванильный Level.explode(): Explosion Overhaul (как и подобные моды)
     * подменяет именно его, поэтому реалистичная физика/частицы подхватываются сами.
     * Сателлитные взрывы разнесены по тикам, чтобы не убивать TPS.
     */
    public static void detonate(ServerLevel level, Vec3 pos, MissileType type) {
        float scale = MissileConfig.POWER_SCALE.get().floatValue();
        Level.ExplosionInteraction mode = MissileConfig.BLOCK_DAMAGE.get()
                ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
        boolean fire = type.fire && MissileConfig.FIRE.get();

        level.explode(null, pos.x, pos.y, pos.z, type.power * scale, fire, mode);

        int sats = overhaulPresent() ? Math.max(0, type.satellites / 2) : type.satellites;
        MinecraftServer server = level.getServer();
        for (int i = 0; i < sats; i++) {
            double a = level.random.nextDouble() * Math.PI * 2;
            double d = 3 + level.random.nextDouble() * type.power * 0.8;
            double x = pos.x + Math.cos(a) * d;
            double y = pos.y + (level.random.nextDouble() - 0.3) * 3;
            double z = pos.z + Math.sin(a) * d;
            int when = server.getTickCount() + 2 + i * 2;
            server.tell(new TickTask(when, () ->
                    level.explode(null, x, y, z, type.power * scale * 0.35f, fire, mode)));
        }
    }

    private ExplosionHelper() {}
}
