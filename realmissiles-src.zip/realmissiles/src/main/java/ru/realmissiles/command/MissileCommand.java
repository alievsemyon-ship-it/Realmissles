package ru.realmissiles.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ru.realmissiles.RealMissilesMod;
import ru.realmissiles.entity.MissileEntity;
import ru.realmissiles.missile.MissileType;
import ru.realmissiles.registry.ModEntities;

import java.util.Arrays;

@Mod.EventBusSubscriber(modid = RealMissilesMod.MODID)
public final class MissileCommand {

    @SubscribeEvent
    public static void onRegister(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("missile").requires(s -> s.hasPermission(2))
                .then(Commands.literal("launch")
                        .then(Commands.argument("type", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(
                                        Arrays.stream(MissileType.values()).filter(MissileType::launchable).map(t -> t.id), b))
                                .then(Commands.argument("target", Vec3Argument.vec3())
                                        .executes(MissileCommand::launch)))));
    }

    private static int launch(CommandContext<CommandSourceStack> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        String id = StringArgumentType.getString(ctx, "type");
        MissileType t = MissileType.byId(id);
        CommandSourceStack src = ctx.getSource();
        if (t == null || !t.launchable()) {
            src.sendFailure(Component.literal("Неизвестный тип: " + id));
            return 0;
        }
        Vec3 target = Vec3Argument.getVec3(ctx, "target");
        ServerLevel level = src.getLevel();
        MissileEntity m = new MissileEntity(ModEntities.of(t), level, t);
        m.setPos(src.getPosition().add(0, 1.5, 0));
        m.launch(target);
        level.addFreshEntity(m);
        src.sendSuccess(() -> Component.literal("Пуск: " + t.id), true);
        return 1;
    }

    private MissileCommand() {}
}
