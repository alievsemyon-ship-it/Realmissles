package ru.realmissiles.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ClientConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue YAW_OFFSET;
    public static final ForgeConfigSpec.BooleanValue INVERT_PITCH;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("model");
        YAW_OFFSET = b.comment("Поворот модели вокруг вертикали (градусы). Если нос смотрит назад, поставьте 180.")
                .defineInRange("yawOffset", 0.0, -360.0, 360.0);
        INVERT_PITCH = b.comment("Если при подъёме нос смотрит вниз, поставьте true.")
                .define("invertPitch", false);
        b.pop();
        SPEC = b.build();
    }

    private ClientConfig() {}
}
