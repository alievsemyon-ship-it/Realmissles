package ru.realmissiles.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class MissileConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue BLOCK_DAMAGE;
    public static final ForgeConfigSpec.BooleanValue FIRE;
    public static final ForgeConfigSpec.DoubleValue SPEED_SCALE;
    public static final ForgeConfigSpec.DoubleValue POWER_SCALE;
    public static final ForgeConfigSpec.ConfigValue<String> EXPLOSION_MOD_ID;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("balance");
        BLOCK_DAMAGE = b.comment("Ломают ли взрывы блоки").define("blockDamage", true);
        FIRE = b.comment("Зажигательные боеголовки поджигают землю").define("fire", true);
        SPEED_SCALE = b.comment("Множитель скорости всех ракет (больше = меньше времени на перехват)")
                .defineInRange("speedScale", 1.0, 0.1, 5.0);
        POWER_SCALE = b.comment("Множитель мощности всех взрывов")
                .defineInRange("powerScale", 1.0, 0.1, 5.0);
        b.pop();
        b.push("compat");
        EXPLOSION_MOD_ID = b.comment("modid Explosion Overhaul (проверьте в mods.toml самого мода)")
                .define("explosionOverhaulModId", "explosionoverhaul");
        b.pop();
        SPEC = b.build();
    }

    private MissileConfig() {}
}
