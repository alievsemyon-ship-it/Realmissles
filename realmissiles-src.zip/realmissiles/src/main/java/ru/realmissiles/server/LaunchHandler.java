package ru.realmissiles.server;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import ru.realmissiles.config.MissileConfig;
import ru.realmissiles.entity.MissileEntity;
import ru.realmissiles.item.MissileItem;
import ru.realmissiles.missile.MissileType;
import ru.realmissiles.network.LaunchPacket;
import ru.realmissiles.registry.ModEntities;

public final class LaunchHandler {

    public static void handle(ServerPlayer p, LaunchPacket m) {
        MissileType[] all = MissileType.values();
        if (m.type < 0 || m.type >= all.length) return;
        MissileType t = all[m.type];
        if (!t.launchable()) return;

        InteractionHand hand = m.mainHand ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
        ItemStack stack = p.getItemInHand(hand);
        if (!(stack.getItem() instanceof MissileItem mi) || mi.getMissileType() != t) {
            msg(p, "Возьмите ракету в руку");
            return;
        }
        if (p.getCooldowns().isOnCooldown(stack.getItem())) return;
        if (p.isPassenger()) { msg(p, "Сначала выйдите из транспорта"); return; }

        ServerLevel level = p.serverLevel();
        Vec3 target = null;

        if (m.mode == 0) {
            if (!Double.isFinite(m.x) || !Double.isFinite(m.y) || !Double.isFinite(m.z)) return;
            target = new Vec3(m.x, m.y, m.z);
            if (target.distanceTo(p.position()) > MissileConfig.MAX_RANGE.get()) {
                msg(p, "Слишком далеко (максимум " + MissileConfig.MAX_RANGE.get().intValue() + " блоков)");
                return;
            }
        } else if (m.mode == 1) {
            HitResult hit = p.pick(MissileConfig.LOOK_RANGE.get(), 1.0f, false);
            if (hit.getType() == HitResult.Type.MISS) { msg(p, "Нет цели: смотрите на землю или блок"); return; }
            target = hit.getLocation();
        } else if (m.mode != 2) {
            return;
        }

        MissileEntity missile = new MissileEntity(ModEntities.of(t), level, t);
        missile.setPos(p.getX(), p.getY() + 2.0, p.getZ());
        if (!level.noCollision(missile)) { msg(p, "Нет места для запуска: над головой препятствие"); return; }

        if (m.mode == 2) missile.launchPilot(p); else missile.launch(target);
        level.addFreshEntity(missile);

        if (m.mode == 2 && !p.startRiding(missile, true)) {
            missile.discard();
            msg(p, "Не удалось занять место пилота");
            return;
        }

        if (!p.getAbilities().instabuild) stack.shrink(1);
        p.getCooldowns().addCooldown(mi, 60);
        msg(p, m.mode == 2 ? "Пуск. Вы пилот. ЛКМ: подрыв, Shift: выход" : "Пуск: " + Component.translatable("entity.realmissiles." + t.id).getString());
    }

    private static void msg(ServerPlayer p, String s) {
        p.displayClientMessage(Component.literal(s), true);
    }

    private LaunchHandler() {}
}
