package ru.realmissiles.server;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import ru.realmissiles.config.MissileConfig;
import ru.realmissiles.entity.MissileEntity;
import ru.realmissiles.item.MissileItem;
import ru.realmissiles.missile.MissileType;
import ru.realmissiles.registry.ModEntities;

public final class LaunchHandler {

    public static void handle(ServerPlayer p, ru.realmissiles.network.LaunchPacket m) {
        InteractionHand hand = m.mainHand ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
        ItemStack stack = p.getItemInHand(hand);
        if (!(stack.getItem() instanceof MissileItem mi)) { msg(p, "hold"); return; }
        MissileType t = mi.getMissileType();
        Item item = stack.getItem();
        if (p.getCooldowns().isOnCooldown(item)) return;

        Vec3 target;
        if (m.mode == 0) {
            if (!Double.isFinite(m.x) || !Double.isFinite(m.y) || !Double.isFinite(m.z)) return;
            target = new Vec3(m.x, m.y, m.z);
        } else if (m.mode == 1) {
            HitResult hit = p.pick(MissileConfig.LOOK_RANGE.get(), 1.0f, false);
            if (hit.getType() == HitResult.Type.MISS) { msg(p, "nolook"); return; }
            target = hit.getLocation();
        } else {
            return;
        }

        double dist = target.distanceTo(p.position());
        if (dist > MissileConfig.MAX_RANGE.get()) { msg(p, "range_max"); return; }
        if (dist < MissileConfig.MIN_RANGE.get()) { msg(p, "range_min"); return; }

        ServerLevel level = p.serverLevel();
        if (!level.canSeeSky(p.blockPosition().above(2))) { msg(p, "sky"); return; }

        MissileEntity missile = new MissileEntity(ModEntities.of(t), level, t);
        missile.setPos(p.getX(), p.getY() + 2.0, p.getZ());
        if (!level.noCollision(missile)) { msg(p, "space"); return; }

        missile.launch(target);
        level.addFreshEntity(missile);

        if (!p.getAbilities().instabuild) stack.shrink(1);
        p.getCooldowns().addCooldown(item, 60);
        msg(p, "launched");
    }

    private static void msg(ServerPlayer p, String key) {
        p.displayClientMessage(Component.translatable("msg.realmissiles." + key), true);
    }

    private LaunchHandler() {}
}
