package ru.realmissiles.server;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import ru.realmissiles.RealMissilesMod;
import ru.realmissiles.entity.MissileEntity;

@Mod.EventBusSubscriber(modid = RealMissilesMod.MODID)
public final class ServerEvents {

    /** Пилот не получает урон от удушья в блоках, а после выхода: от взрыва и падения. */
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (p.getVehicle() instanceof MissileEntity && e.getSource().is(DamageTypes.IN_WALL)) {
            e.setCanceled(true);
            return;
        }
        Long until = MissileEntity.SAFE.get(p.getUUID());
        if (until == null) return;
        if (p.level().getGameTime() > until) { MissileEntity.SAFE.remove(p.getUUID()); return; }
        if (e.getSource().is(DamageTypeTags.IS_EXPLOSION) || e.getSource().is(DamageTypeTags.IS_FALL)
                || e.getSource().is(DamageTypes.IN_WALL)) {
            e.setCanceled(true);
        }
    }

    /** Если пилот вышел из игры в полёте: вернуть на точку пуска. */
    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity().getVehicle() instanceof MissileEntity) e.getEntity().stopRiding();
    }

    private ServerEvents() {}
}
