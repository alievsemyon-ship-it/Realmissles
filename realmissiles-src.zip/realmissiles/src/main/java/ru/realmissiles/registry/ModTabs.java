package ru.realmissiles.registry;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import ru.realmissiles.RealMissilesMod;
import ru.realmissiles.missile.MissileType;

public final class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RealMissilesMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.realmissiles"))
                    .icon(() -> new ItemStack(ModItems.of(MissileType.ISKANDER)))
                    .displayItems((params, out) -> {
                        for (MissileType t : MissileType.values()) {
                            if (t.launchable()) out.accept(ModItems.of(t));
                        }
                    })
                    .build());

    private ModTabs() {}
}
