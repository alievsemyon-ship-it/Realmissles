package ru.realmissiles.registry;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import ru.realmissiles.RealMissilesMod;
import ru.realmissiles.entity.MissileEntity;
import ru.realmissiles.missile.MissileType;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, RealMissilesMod.MODID);

    private static final Map<MissileType, RegistryObject<EntityType<MissileEntity>>> MAP = new EnumMap<>(MissileType.class);

    static {
        for (MissileType t : MissileType.values()) {
            MAP.put(t, ENTITIES.register(t.id, () ->
                    EntityType.Builder.<MissileEntity>of((type, level) -> new MissileEntity(type, level, t), MobCategory.MISC)
                            .sized(t.width, t.height)
                            .clientTrackingRange(32)
                            .updateInterval(1)
                            .fireImmune()
                            .build(t.id)));
        }
    }

    public static EntityType<MissileEntity> of(MissileType t) { return MAP.get(t).get(); }

    private ModEntities() {}
}
