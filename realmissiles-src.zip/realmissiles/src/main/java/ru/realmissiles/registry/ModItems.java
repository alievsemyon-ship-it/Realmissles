package ru.realmissiles.registry;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import ru.realmissiles.RealMissilesMod;
import ru.realmissiles.item.MissileItem;
import ru.realmissiles.missile.MissileType;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, RealMissilesMod.MODID);

    private static final Map<MissileType, RegistryObject<Item>> MAP = new EnumMap<>(MissileType.class);

    static {
        for (MissileType t : MissileType.values()) {
            if (!t.launchable()) continue;
            MAP.put(t, ITEMS.register(t.id + "_missile",
                    () -> new MissileItem(t, new Item.Properties().stacksTo(1))));
        }
    }

    public static Item of(MissileType t) { return MAP.get(t).get(); }

    private ModItems() {}
}
