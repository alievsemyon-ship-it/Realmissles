package ru.realmissiles.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import ru.realmissiles.missile.MissileType;

import java.util.List;
import java.util.function.BiConsumer;

public class MissileItem extends Item {
    /** Устанавливается клиентом (ClientSetup): открывает меню запуска. */
    public static BiConsumer<MissileType, InteractionHand> OPEN_SCREEN;

    private final MissileType type;

    public MissileItem(MissileType type, Properties props) {
        super(props);
        this.type = type;
    }

    public MissileType getMissileType() { return type; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide && OPEN_SCREEN != null) OPEN_SCREEN.accept(type, hand);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.realmissiles.use"));
        tooltip.add(Component.translatable("tooltip.realmissiles.sky"));
    }
}
