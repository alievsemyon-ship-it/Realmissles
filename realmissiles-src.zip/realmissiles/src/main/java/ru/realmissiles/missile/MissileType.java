package ru.realmissiles.missile;

public enum MissileType {
    // id, hp, armor(пули), explosionResist, speed(б/тик), terminalMul, boostTicks, cruiseAlt, apexHeight,
    // terminalDist, power, satellites, splitCount, splitDist, fire, jamSusceptibility, hitW, hitH
    FLAMINGO("flamingo", 80f, 0.15f, 0.80f, 1.6, 1.0, 40, 35, 0, 90, 12f, 4, 0, 0, false, 0.9, 0.9f, 1.0f),
    ISKANDER("iskander", 160f, 0.50f, 0.50f, 2.5, 1.8, 60, 0, 220, 0, 14f, 5, 0, 0, false, 0.1, 1.0f, 1.0f),
    ORESHNIK("oreshnik", 900f, 0.95f, 0.30f, 3.5, 2.0, 80, 0, 400, 0, 6f, 0, 6, 260, false, 0.0, 1.2f, 1.2f),
    WARHEAD("warhead", 25f, 0.30f, 0.50f, 5.0, 1.0, 0, 0, 0, 0, 9f, 2, 0, 0, true, 0.0, 0.5f, 0.5f);

    public final String id;
    public final float health, armor, explosionResist, power, width, height;
    public final double speed, terminalMul, jamSusceptibility;
    public final int boostTicks, cruiseAlt, apexHeight, terminalDist, satellites, splitCount, splitDistance;
    public final boolean fire;

    MissileType(String id, float health, float armor, float explosionResist, double speed, double terminalMul,
                int boostTicks, int cruiseAlt, int apexHeight, int terminalDist, float power, int satellites,
                int splitCount, int splitDistance, boolean fire, double jam, float width, float height) {
        this.id = id; this.health = health; this.armor = armor; this.explosionResist = explosionResist;
        this.speed = speed; this.terminalMul = terminalMul; this.boostTicks = boostTicks;
        this.cruiseAlt = cruiseAlt; this.apexHeight = apexHeight; this.terminalDist = terminalDist;
        this.power = power; this.satellites = satellites; this.splitCount = splitCount;
        this.splitDistance = splitDistance; this.fire = fire; this.jamSusceptibility = jam;
        this.width = width; this.height = height;
    }

    /** Расстояние от центра до сопла в блоках (по длине модели). */
    public double tailOffset() {
        return switch (this) {
            case FLAMINGO -> 3.0;
            case ISKANDER -> 3.1;
            case ORESHNIK -> 4.0;
            case WARHEAD -> 0.7;
        };
    }

    public boolean isCruise() { return cruiseAlt > 0; }
    public boolean launchable() { return this != WARHEAD; }

    public static MissileType byId(String id) {
        for (MissileType t : values()) if (t.id.equals(id)) return t;
        return null;
    }
}
